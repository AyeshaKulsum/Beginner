const chai = require("chai");
const chaiHttp = require("chai-http");

const app = require("../index").app;
const mongoClient = require("../index").mongoClient;

const should = chai.should();
const expect = chai.expect;
chai.use(chaiHttp);


describe("City Routes =>", ()=> {

    let newState = `test-state-${Math.random() * 10000}`,
        newCity = `test-city-${newState}`;

    before((done)=> {
        chai.request(app).post("/states").send({state: newState}).end();
        done();
    });

	describe("Adding a city under a state =>", ()=> {

        it("should reject request without city name", (done) => {
            chai.request(app)
                .post(`/states/${newState}`)
                .end((err, res)=> {
                    expect(err).to.be.null;
                    expect(res).to.have.status(400);
                    done();
                });
        });

        it("should create a new city under a state", (done) => {
            chai.request(app)
                .post(`/states/${newState}`)
                .send({
                    city: newCity
                })
                .end((err, res)=> {
                    expect(err).to.be.null;
                    expect(res).to.have.status(200);
                    expect(res.body.state).to.equal(newState);
                    expect(res.body.cities).to.include(newCity);
                    done();
                });
        });

        it("should return the newly created city", (done) => {
            chai.request(app)
                .get(`/states/${newState}`)
                .end((err, res)=> {
                    expect(err).to.be.null;
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an("array");
                    expect(res.body.indexOf(newCity)).to.not.equal(-1);

                    done();
                });
        });

    });

    describe("Removing a city under a state =>", ()=> {

        it("should remove a city under a state", (done) => {
            chai.request(app)
                .delete(`/states/${newState}/${newCity}`)
                .end((err, res)=> {
                    expect(err).to.be.null;
                    expect(res).to.have.status(200);
                    expect(res.body.state).to.equal(newState);
                    expect(res.body.cities).to.not.include(newCity);
                    done();
                });
        });

    });

});
