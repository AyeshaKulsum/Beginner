const chai = require("chai");
const chaiHttp = require("chai-http");

const app = require("../index").app;
const mongoClient = require("../index").mongoClient;

const should = chai.should();
const expect = chai.expect;
chai.use(chaiHttp);


describe("State Routes =>", ()=> {

    let newState = `test-state-${Math.random()}`;

    it("should reject request without state name", (done) => {
        chai.request(app)
            .post("/states")
            .end((err, res)=> {
                expect(err).to.be.null;
                expect(res).to.have.status(400);
                done();
            });
    });

	it("should create a new state", (done) => {
        chai.request(app)
            .post("/states")
            .send({
            	state: newState
            })
            .end((err, res)=> {
            	expect(err).to.be.null;
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("_id");
                expect(res.body).to.have.property("cities");
                expect(res.body.state).to.equal(newState);
                done();
            });
    });

    it("should return the new state with the existing ones", (done) => {
        chai.request(app)
            .get("/states")
            .end((err, res)=> {
                expect(err).to.be.null;
                expect(res).to.have.status(200);
                expect(res.body).to.be.an("array");

                let returned = res.body.filter( s => s.state === newState)[0];
                expect(returned).to.be.an("object");
                expect(returned.state).to.equal(newState);

                done();
            });
    });

});
