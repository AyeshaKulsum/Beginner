// Solution to the Skillenza challenge - backend

const express = require("express");
const mongo = require("mongodb");
const bodyParser = require("body-parser");


// Express setup
const app = express();
const PORT = process.env.PORT || 5000;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Mongo connection and setup
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/skillenza";
const MONGO_DB_NAME = process.env.MONGO_DB_NAME || "skillenza";
const mongoClient = new mongo.MongoClient(MONGO_URI, {useNewUrlParser: true});

let DB, States;
mongoClient.connect(function(err) {
    if(err) { return console.log("error connecting to ", MONGO_URI); }
    DB = mongoClient.db(MONGO_DB_NAME);
    States = DB.collection("states");
});


app.get('/', function(req, res){
  res.send("ok")
})


app.listen(PORT);

module.exports = {
    app: app,
    DB: DB
};
