# Backend Challenge - Express + Mongo

The goal of this challenge is to create a REST API server using Express and MongoDB. The API endpoints are meant to manage data related to states and their cities of a country.

All the endpoints should accept and return data in JSON format.

In the MongoDB, the `states` collection should store data in the following format :

```js
[
    {
        "_id": "5cff6dbc72e3e41bb04134bd",
        "state": "punjab",
        "cities": [
          "mohali",
          "ludhiana",

          ...
        ]
    },

    ...
]
```

The endpoints you need to create are -


#### 1. List all states in the database

Endpoint - `GET /states`

Sample response -

```js
[
  {
    "_id": "5cff6cdb72e3e41bb04134bc",
    "state": "karnataka",
    "cities": [
      "bangalore",
      "dharward",
      "hubli",
      "mysore"
    ]
  },
  {
    "_id": "5cff6dbc72e3e41bb04134bd",
    "state": "punjab",
    "cities": [
      "mohali"
    ]
  }
]
```

As the name suggests, this endpoint should return all the states in the database in the above format.


#### 2. Create a new state

Endpoint - `POST /states`

Sample request -

```js
{
    "state": "karnataka"
}
```

Sample response -

```js
{
  "state": "karnataka",
  "cities": [],
  "_id": "5cff6cdb72e3e41bb04134bc"
}
```

This route should take `state` from the request body and create a new state in the database.

It should validate the incoming data and return HTTP status `400` if `state` is not found in the request body.


#### 3. List all cities under a state

Endpoint - `GET /states/:state`

Sample request -

```
/GET /states/karnataka
```

Sample response -

```js
[
  "bangalore",
  "dharward",
  "hubli",
  "mysore"
]
```

This route should return all the cities under a state specified in the request parameter - `state` - following the exact format as the sample response above.


#### 4. Create a city under a state

Endpoint - `POST /states/:state`

Sample URL -
```
POST /states/karnataka
```

Sample request -

```js
{
    "city": "bangalore"
}
```

Sample response -

```js
{
  "_id": "5cff6cdb72e3e41bb04134bc",
  "state": "karnataka",
  "cities": [
    "bangalore",
    "dharward",
    "hubli",
    "mysore"
  ]
}
```

This route should take `city` from the request body and create a new city in the database under the `state` parameter specified in the URL as a request parameter. The new city should be added to the `cities` array inside the `state` document.

It should validate the incoming data and return HTTP status `400` if `city` is not found in the request body.


#### 5. Deletes a city under a state

Endpoint - `DELETE /states/:state/:city`

Sample request URL -

```
DELETE /states/karnataka/mysore
```

Sample response -

```js
{
  "_id": "5cff6cdb72e3e41bb04134bc",
  "state": "karnataka",
  "cities": [
    "bangalore",
    "dharward",
    "hubli"
  ]
}
```

This route should take `city` from the request parameters and remove the city under the `state` parameter specified in the URL.

The specified `city` should be taken out of the `cities` array of the state document.


## Running the test cases

Inorder for the tests to run, you have to export your express app variable named `app` from your `index.js` file.

You can run the tests by running `npm test` from the project directory.

Also, You have to follow the exact request and response parameters, body and formatting for the tests to pass.
